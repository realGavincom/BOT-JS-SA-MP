require('dotenv').config();

const { Client, GatewayIntentBits, ActivityType, Partials, EmbedBuilder } = require('discord.js');
const config = require('./config.json');
const voteCommand = require('./Event/Votting.js');
const functionEvent = require('./Generator/Function.js');

const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.MessageContent,
        GatewayIntentBits.GuildMembers,
        GatewayIntentBits.GuildInvites,
        GatewayIntentBits.GuildMessageReactions,
        GatewayIntentBits.GuildModeration
    ],
    partials: [Partials.Message, Partials.Reaction]
});

// Inisialisasi Command
require('./Commands/SlashCMD')(client, process.env.CLIENT_ID, process.env.GUILD_ID);

// Load Event
require('./Event/PanelRegister')(client, config.memberRoleId, config.allowedRoleId);
require('./Event/ClearMessage')(client);
require('./Event/Pengumuman')(client);
require('./Event/TicketDonation')(client);
require('./Event/ThreadG')(client);
require('./Event/CharStory')(client);
require('./Event/CharKilled')(client);

// Load Generator
require('./Generator/IPAuto')(client);
require('./Generator/Protect.js')(client);

// Invite Cache
const inviteCache = new Map();

client.on('ready', async () => {
    console.log(`${client.user.tag} aktif!`);
    client.user.setActivity('Beta Version', { type: ActivityType.Playing });

    try {
        const guild = client.guilds.cache.get(process.env.GUILD_ID);
        const invites = await guild.invites.fetch();
        invites.each(invite => {
            inviteCache.set(invite.code, {
                uses: invite.uses,
                inviterId: invite.inviter.id
            });
        });
    } catch (error) {
        console.error('Error initializing invites:', error);
    }
});

client.on('interactionCreate', async (interaction) => {
    if (interaction.isCommand()) {
        if (interaction.commandName === 'votepanel') {
            await voteCommand.execute(interaction);
        }
    } else if (interaction.isButton()) {
        await functionEvent.execute(interaction);
    }
});

client.on('guildMemberAdd', async member => {
    try {
        const welcomeChannel = member.guild.channels.cache.get(config.welcomeChannelId);
        if (welcomeChannel) {
            const embed = new EmbedBuilder()
                .setColor('#00FF00')
                .setTitle('**👋 Welcome!**')
                .setDescription(`**Hallo, Selamat Datang ${member.user}\n📍Jangan Lupa Verify Role Di <#1325304226976370739>\n📕 Jangan Lupa Membaca Rules Di <#1325095643072561212>\n🗃️ Jangan Lupa Membuat Account Di <#1326858655148015657>**\n__**TTD.**\n***Team Horizontal***__`)
                .setThumbnail(member.user.displayAvatarURL())
                .setTimestamp();
            await welcomeChannel.send({ embeds: [embed] });
        }
    } catch (error) {
        console.error('Error sending welcome message:', error);
    }

    try {
        const newInvites = await member.guild.invites.fetch();
        const usedInvite = newInvites.find(inv => inviteCache.get(inv.code)?.uses < inv.uses);

        if (usedInvite) {
            const inviter = await client.users.fetch(usedInvite.inviter.id);
            const logChannel = member.guild.channels.cache.get(config.inviteLogsChannelId);

            if (logChannel) {
                const embed = new EmbedBuilder()
                    .setColor('#0099FF')
                    .setTitle('📨 New Invite')
                    .setDescription(`**${member.user} was invited by ${inviter}**\n**Total invites: ${usedInvite.uses}**`)
                    .setThumbnail(member.user.displayAvatarURL())
                    .setTimestamp();
                await logChannel.send({ embeds: [embed] });
            }

            inviteCache.set(usedInvite.code, {
                uses: usedInvite.uses,
                inviterId: inviter.id
            });
        }
    } catch (error) {
        console.error('Error tracking invite:', error);
    }
});

client.on('guildMemberRemove', async member => {
    try {
        const leaveChannel = member.guild.channels.cache.get(config.leaveChannelId);
        if (leaveChannel) {
            const embed = new EmbedBuilder()
                .setColor('#FF0000')
                .setTitle('**👋 Goodbye!**')
                .setDescription(`**📤 ${member.user} has left the server!**`)
                .setThumbnail(member.user.displayAvatarURL())
                .setTimestamp();
            await leaveChannel.send({ embeds: [embed] });
        }
    } catch (error) {
        console.error('Error sending leave message:', error);
    }
});

client.on('inviteCreate', invite => {
    inviteCache.set(invite.code, {
        uses: invite.uses,
        inviterId: invite.inviter.id
    });
});

client.on('inviteDelete', invite => {
    inviteCache.delete(invite.code);
});

client.login(process.env.TOKEN);