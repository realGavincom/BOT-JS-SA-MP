const { 
    Events, 
    EmbedBuilder, 
    ActionRowBuilder, 
    ButtonBuilder, 
    ButtonStyle, 
    PermissionFlagsBits, 
    ChannelType 
} = require('discord.js');
const config = require('../config.json');

module.exports = (client) => {
    const joinHistory = new Map();
    const lockdownMode = new Set();

    // Deteksi join massal
    client.on('guildMemberAdd', async (member) => {
        const guild = member.guild;
        const now = Date.now();
        
        if (!joinHistory.has(guild.id)) {
            joinHistory.set(guild.id, []);
        }
        
        const joins = joinHistory.get(guild.id);
        joins.push(now);
        
        const recentJoins = joins.filter(timestamp => now - timestamp < 10000);
        joinHistory.set(guild.id, recentJoins);
        
        if (recentJoins.length > 5 && !lockdownMode.has(guild.id)) {
            lockdownMode.add(guild.id);
            
            const channel = guild.systemChannel || guild.channels.cache.find(c => c.type === 'GUILD_TEXT');
            if (channel) {
                channel.send(`🚨 **RAID DETECTED!** Enabling lockdown mode!`);
            }
            
            await enableLockdown(guild);
            
            recentJoins.forEach(async (timestamp, index) => {
                try {
                    await guild.members.kick(member);
                } catch (error) {
                    console.error('Failed to kick member:', error);
                }
            });
            
            setTimeout(() => {
                lockdownMode.delete(guild.id);
                disableLockdown(guild);
            }, 300000);
        }
    });

    // Blokir pembuatan invite massal
    client.on('inviteCreate', async (invite) => {
        if (lockdownMode.has(invite.guild.id)) {
            await invite.delete();
            await invite.guild.members.kick(invite.inviter);
        }
    });

    // Deteksi channel spam
    client.on('channelCreate', async (channel) => {
        const guild = channel.guild;
        if (lockdownMode.has(guild.id)) {
            await channel.delete();
            const creator = await guild.fetchAuditLogs({ type: 'CHANNEL_CREATE' }).then(audit => audit.entries.first());
            if (creator) {
                await guild.members.kick(creator.executor);
            }
        }
    });

    // Fungsi lockdown
    async function enableLockdown(guild) {
        const everyone = guild.roles.everyone;
        await everyone.edit({ permissions: everyone.permissions.remove('SEND_MESSAGES') });
        
        const invites = await guild.invites.fetch();
        invites.forEach(invite => invite.delete());
    }

    async function disableLockdown(guild) {
        const everyone = guild.roles.everyone;
        await everyone.edit({ permissions: everyone.permissions.add('SEND_MESSAGES') });
        
        const channel = guild.systemChannel || guild.channels.cache.find(c => c.type === 'GUILD_TEXT');
        if (channel) {
            channel.send(`🔓 **Lockdown mode disabled**. Server back to normal.`);
        }
    }

    // Command manual lockdown
    client.on('messageCreate', async (message) => {
        if (message.content === '!lockdown' && message.member.permissions.has('ADMINISTRATOR')) {
            const guild = message.guild;
            lockdownMode.add(guild.id);
            await enableLockdown(guild);
            message.reply('🔒 Lockdown mode enabled!');
        }
    });

    // Logging system
    client.on(Events.MessageDelete, async (message) => {
        if (message.author?.bot) return;

        try {
            const logChannel = client.channels.cache.get(config.logChannelId);
            if (!logChannel) {
                console.error('Log channel tidak ditemukan!');
                return;
            }

            const embed = new EmbedBuilder()
                .setColor(0x0099FF)
                .setTitle('📝 Log Aktivitas Sistem')
                .setDescription('**Aksi Penghapusan Konten Terdeteksi**')
                .addFields(
                    { name: '🗑️ Konten Dihapus', value: message.content?.slice(0, 1024) || '*[Konten tidak dapat ditampilkan]*' },
                    { name: '👤 Pengguna', value: message.author?.toString() || 'Tidak Diketahui' },
                    { name: '📌 Lokasi', value: message.channel?.toString() || 'Unknown Channel' },
                    { name: '🕒 Waktu', value: `<t:${Math.floor(Date.now() / 1000)}:F>` }
                )
                .setFooter({ text: 'Sistem Pelacakan Aktivitas • SecureLog v1.0' });

            const row = new ActionRowBuilder().addComponents(
                new ButtonBuilder()
                    .setLabel('Lokasi Pesan')
                    .setURL(message.url)
                    .setStyle(ButtonStyle.Link)
            );

            await logChannel.send({ embeds: [embed], components: [row] });
        } catch (error) {
            console.error('Error handling message delete:', error);
        }
    });

    // Security system
    client.on('messageCreate', async (message) => {
        if (message.author.bot) return;

        const badWords = ['anjing', 'goblok', 'kontol', 'bangsat', 'asu', 'pantek', 'jancok', 'anjg', 'gblk', 'kntl', 'bngst', 'pntek', 'jncok', 'tolol', 'tlol', 'mmk', 'memek', 'pler'];
        const forbiddenDomains = ['free-money.com', 'phishing-site.net', 'scam-domain.org'];
        const content = message.content.toLowerCase();

        const hasBadWord = badWords.some(word => content.includes(word));
        const hasForbiddenLink = forbiddenDomains.some(domain => content.includes(domain));
        const linkRegex = /(https?:\/\/[^\s]+)/g;
        const linkCount = (content.match(linkRegex) || []).length;

        try {
            if (hasBadWord) {
                await message.delete();
                
                const muteRole = message.guild.roles.cache.find(role => role.name === 'Muted');
                if (!muteRole) return;

                const member = message.member;
                await member.roles.add(muteRole);
                
                setTimeout(async () => {
                    await member.roles.remove(muteRole);
                }, 5 * 60 * 1000);

                message.channel.send(`${message.author} telah di-mute selama 5 menit karena menggunakan kata-kata tidak pantas.`);
            }
            else if (hasForbiddenLink || linkCount > 5) {
                await message.delete();
                await message.member.kick('Mengirim link terlarang/spam');
                message.channel.send(`${message.author} telah di-kick karena melanggar kebijakan link.`);
            }
        } catch (error) {
            console.error('Error handling security:', error);
        }
    });
};