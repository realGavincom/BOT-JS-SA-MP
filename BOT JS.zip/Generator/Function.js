const { EmbedBuilder } = require('discord.js');
const { voteRecords } = require('../Event/Votting.js');

module.exports = {
    name: 'interactionCreate',
    async execute(interaction) {
        if (!interaction.isButton()) return;

        const { customId, message, user } = interaction;
        const voteData = voteRecords.get(message.id);

        if (!['vote_setuju', 'vote_tidak_setuju'].includes(customId) || !voteData) {
            return;
        }

        const hasVoted = voteData.setuju.has(user.id) || voteData.tidakSetuju.has(user.id);
        if (hasVoted) {
            return interaction.reply({ 
                content: '❌ Anda sudah melakukan vote sebelumnya!', 
                ephemeral: true 
            });
        }

        if (customId === 'vote_setuju') {
            voteData.setuju.add(user.id);
        } else {
            voteData.tidakSetuju.add(user.id);
        }

        const updatedEmbed = EmbedBuilder.from(message.embeds[0])
            .spliceFields(0, 1, {
                name: '📊 Hasil Voting',
                value: `Setuju: ${voteData.setuju.size}\nTidak Setuju: ${voteData.tidakSetuju.size}`
            });

        await interaction.reply({ content: `Anda memilih **${customId === 'vote_setuju' ? 'Setuju' : 'Tidak Setuju'}**!`, ephemeral: true });
        await interaction.message.edit({ embeds: [updatedEmbed] });
    }
};