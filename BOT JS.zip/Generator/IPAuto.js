const { EmbedBuilder } = require('discord.js'); 

module.exports = (client) => {
    client.on('messageCreate', async message => {
        if (message.author.bot) return;

        console.log(`Pesan diterima: ${message.content}`); 

        const triggers = ['ip', 'addres']; 
        const response = triggers.some(trigger => 
            message.content.toLowerCase().includes(trigger)
        );

        console.log(`Trigger ditemukan: ${response}`); 

        if (response) {
            const embed = new EmbedBuilder()
                .setColor('#FFD700')
                .setDescription(`**📡 IP Here! <#1325096947559960686>**`)
                .setTimestamp();

            await message.reply({ embeds: [embed] });
            console.log(`Embed dikirim sebagai respons`); 
        }
    });
};