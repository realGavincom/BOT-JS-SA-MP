const { REST, Routes } = require('discord.js');
const config = require('../config.json');

module.exports = (client, clientId, guildId) => {
    const commands = [
        {
            name: 'charstorypanel',
            description: 'Buat panel Character Story [Admin Only]',
            options: [
                {
                    name: 'channel',
                    type: 7,
                    description: 'Pilih channel untuk panel',
                    required: true
                }
            ]
        },
        {
            name: 'charkilledpanel',
            description: 'Buat panel Character Killed [Admin Only]',
            options: [
                {
                    name: 'channel',
                    type: 7,
                    description: 'Pilih channel untuk panel',
                    required: true
                }
            ]
        },
        {
            name: 'votepanel',
            description: 'Buat panel voting [Admin Only]',
            options: [
                {
                    name: 'judul',
                    type: 3,
                    description: 'Judul voting',
                    required: true
                },
                {
                    name: 'deskripsi',
                    type: 3,
                    description: 'Deskripsi voting',
                    required: true
                },
                {
                    name: 'pilihan_pertama',
                    type: 3,
                    description: 'Teks untuk pilihan pertama',
                    required: true
                },
                {
                    name: 'pilihan_kedua',
                    type: 3,
                    description: 'Teks untuk pilihan kedua',
                    required: true
                },
                {
                    name: 'emoji_pertama',
                    type: 3,
                    description: 'Emoji untuk pilihan pertama (contoh: 👍)',
                    required: false
                },
                {
                    name: 'emoji_kedua',
                    type: 3,
                    description: 'Emoji untuk pilihan kedua (contoh: 👎)',
                    required: false
                }
            ]
        },
        {
            name: 'ticketpanel',
            description: 'Buat panel ticket [Admin Only]',
            options: [
                {
                    name: 'channel',
                    type: 7,
                    description: 'Pilih channel untuk panel',
                    required: true
                }
            ]
        },
        {
            name: 'panelregister',
            description: 'Buat panel registrasi [Admin Only]',
            options: [
                {
                    name: 'channel',
                    type: 7,
                    description: 'Pilih channel untuk panel',
                    required: true
                }
            ]
        },
        {
            name: 'clear',
            description: 'Hapus pesan [Admin Only]',
            options: [
                {
                    name: 'jumlah',
                    type: 4,
                    description: "Jumlah pesan (1-1000)",
                    required: true
                }
            ]
        },
        {
            name: 'pengumuman',
            description: 'Buat pengumuman [Admin Only]',
            options: [
                {
                    name: 'channel',
                    type: 7,
                    description: 'Channel untuk pengumuman',
                    required: true
                },
                {
                    name: 'judul',
                    type: 3,
                    description: 'Judul pengumuman',
                    required: true
                },
                {
                    name: 'deskripsi',
                    type: 3,
                    description: 'Isi pengumuman',
                    required: true
                }
            ]
        }
    ];

    const rest = new REST({ version: '10' }).setToken(process.env.TOKEN);

    (async () => {
        try {
            console.log('Memulai update commands...');
            await rest.put(Routes.applicationGuildCommands(clientId, guildId), { body: commands });
            console.log('Commands berhasil diupdate!');
        } catch (error) {
            console.error('Error saat mengupdate commands:', error);
        }
    })();
};