const { 
    ActionRowBuilder, 
    ButtonBuilder, 
    ButtonStyle, 
    PermissionFlagsBits, 
    ChannelType,
    EmbedBuilder 
} = require('discord.js');
const config = require('../config.json');

module.exports = (client) => {
    function createCloseButton() {
        return new ActionRowBuilder().addComponents(
            new ButtonBuilder()
                .setCustomId('close_ticket')
                .setLabel('🔒 Tutup Ticket')
                .setStyle(ButtonStyle.Danger)
        );
    }

    client.on('interactionCreate', async (interaction) => {
        try {
            if (interaction.isCommand() && interaction.commandName === 'ticketpanel') {
                if (!interaction.member.roles.cache.has(config.adminRoleId)) {
                    return interaction.reply({ 
                        content: '⛔ **Akses Ditolak!** Anda tidak memiliki izin untuk menggunakan perintah ini.', 
                        ephemeral: true 
                    });
                }

                const embed = new EmbedBuilder()
                    .setColor('#FDFD96')
                    .setTitle('**📝 Donation Panel**')
                    .setDescription('**Gunakan menu tiket dengan bijak. Dilarang melakukan trolling atau menekan tombol tiket tanpa tujuan yang jelas. Pelanggaran terhadap aturan ini akan dikenakan sanksi sesuai ketentuan yang berlaku.**');

                const row = new ActionRowBuilder()
                    .addComponents(
                        new ButtonBuilder()
                            .setCustomId('topup_ticket')
                            .setLabel('💳 Top Up')
                            .setStyle(ButtonStyle.Success),
                        new ButtonBuilder()
                            .setCustomId('paket_menu')
                            .setLabel('📋 Paket Menu')
                            .setStyle(ButtonStyle.Primary),
                        new ButtonBuilder()
                            .setCustomId('payment_info')
                            .setLabel('💸 Payment')
                            .setStyle(ButtonStyle.Secondary)
                    );

                await interaction.reply({
                    embeds: [embed],
                    components: [row]
                });
            }

            if (interaction.isButton()) {
                switch(interaction.customId) {
                    case 'topup_ticket':
                        const channel = await interaction.guild.channels.create({
                            name: `topup-${interaction.user.username}`,
                            type: ChannelType.GuildText,
                            parent: config.ticketCategoryId,
                            permissionOverwrites: [
                                {
                                    id: interaction.guild.id,
                                    deny: [PermissionFlagsBits.ViewChannel]
                                },
                                {
                                    id: interaction.user.id,
                                    allow: [
                                        PermissionFlagsBits.ViewChannel,
                                        PermissionFlagsBits.SendMessages
                                    ]
                                },
                                {
                                    id: config.adminRoleId,
                                    allow: [
                                        PermissionFlagsBits.ViewChannel,
                                        PermissionFlagsBits.ManageMessages
                                    ]
                                },
                                {
                                    id: client.user.id,
                                    allow: [
                                        PermissionFlagsBits.ViewChannel,
                                        PermissionFlagsBits.ManageChannels
                                    ]
                                }
                            ]
                        });

                        const logChannel = interaction.guild.channels.cache.get(config.ticketLogsChannelId);
                        await logChannel.send(`📥 **Ticket dibuat oleh** ${interaction.user.tag} di ${channel}`);

                        await channel.send({
                            content: `${interaction.user} **Selamat datang di ticket Top Up!**\nSilakan berikan detail top up yang diperlukan:`,
                            components: [createCloseButton()]
                        });

                        await interaction.reply({
                            content: `✅ **Ticket berhasil dibuat:** ${channel}`,
                            ephemeral: true
                        });
                        break;

                    case 'close_ticket':
                        if (!interaction.member.roles.cache.has(config.adminRoleId)) {
                            return interaction.reply({ 
                                content: '⛔ **Hanya admin yang bisa menutup ticket!**', 
                                ephemeral: true 
                            });
                        }

                        const confirmRow = new ActionRowBuilder()
                            .addComponents(
                                new ButtonBuilder()
                                    .setCustomId('confirm_close')
                                    .setLabel('📁 Arsipkan Ticket')
                                    .setStyle(ButtonStyle.Secondary),
                                new ButtonBuilder()
                                    .setCustomId('delete_ticket')
                                    .setLabel('🗑️ Hapus Ticket')
                                    .setStyle(ButtonStyle.Danger),
                                new ButtonBuilder()
                                    .setCustomId('cancel_close')
                                    .setLabel('❌ Batal')
                                    .setStyle(ButtonStyle.Danger)
                            );

                        await interaction.reply({
                            content: '**📁 Apakah Anda yakin ingin mengarsipkan atau menghapus ticket ini?**',
                            components: [confirmRow],
                            ephemeral: true
                        });
                        break;

                    case 'paket_menu':
                        try {
                            const dm = await interaction.user.createDM();
                            await dm.send('**📋 Daftar Paket Menu:**\n1. <#1325124471920660623>');
                            await interaction.reply({ 
                                content: '✅ **Menu telah dikirim ke DM Anda!**', 
                                ephemeral: true 
                            });
                        } catch {
                            await interaction.reply({ 
                                content: '⚠️ **Tidak dapat mengirim DM! Pastikan DM terbuka.**', 
                                ephemeral: true 
                            });
                        }
                        break;

                    case 'payment_info':
                        try {
                            const dm = await interaction.user.createDM();
                            await dm.send('**💳 Informasi Pembayaran:\n**```Dana: +62 882-4527-4760\nGopay: +62 882-4527-4760```\n**Qris:**\nhttps://cdn.discordapp.com/attachments/1335613232286662731/1336302398012133479/Kode_QRIS_Hosting_RL_L.png?ex=67a35016&is=67a1fe96&hm=95b1109559fb2af595d3ce2c7283bff46bdef7acd518c4c3dcf6ff38510d4b73&');
                            await interaction.reply({ 
                                content: '✅ **Informasi pembayaran telah dikirim ke DM!**', 
                                ephemeral: true 
                            });
                        } catch {
                            await interaction.reply({ 
                                content: '⚠️ **Tidak dapat mengirim DM! Pastikan DM terbuka.**', 
                                ephemeral: true 
                            });
                        }
                        break;

                    case 'confirm_close':
                        try {
                            if (!config.ticketArchiveCategoryId) {
                                return interaction.reply({
                                    content: '❌ **Kategori arsip belum dikonfigurasi**',
                                    ephemeral: true
                                });
                            }

                            await interaction.channel.setParent(config.ticketArchiveCategoryId);
                            await interaction.channel.permissionOverwrites.delete(interaction.user.id);
                            await interaction.channel.setName(`archived-${interaction.channel.name}`);

                            const logChannel = interaction.guild.channels.cache.get(config.ticketLogsChannelId);
                            await logChannel.send(`📁 **Ticket diarsipkan oleh** ${interaction.user.tag}: ${interaction.channel}`);

                            await interaction.update({ 
                                content: '✅ **Ticket telah diarsipkan!**', 
                                components: [] 
                            });

                            await interaction.channel.send({
                                content: `📂 **Ticket ini telah diarsipkan oleh** ${interaction.user}\n_Channel akan dibekukan dan hanya admin yang bisa melihat_`
                            });
                        } catch (error) {
                            console.error('Error arsipkan ticket:', error);
                            await interaction.reply({
                                content: '❌ **Gagal mengarsipkan ticket**',
                                ephemeral: true
                            });
                        }
                        break;

                    case 'delete_ticket':
                        try {
                            if (!interaction.member.roles.cache.has(config.adminRoleId)) {
                                return interaction.reply({ 
                                    content: '⛔ **Hanya admin yang bisa menghapus ticket!**', 
                                    ephemeral: true 
                                });
                            }

                            await interaction.channel.delete();

                            const logChannel = interaction.guild.channels.cache.get(config.ticketLogsChannelId);
                            await logChannel.send(`🗑️ **Ticket dihapus oleh** ${interaction.user.tag}: ${interaction.channel.name}`);
                        } catch (error) {
                            console.error('Error hapus ticket:', error);
                            await interaction.reply({
                                content: '❌ **Gagal menghapus ticket**',
                                ephemeral: true
                            });
                        }
                        break;

                    case 'cancel_close':
                        await interaction.update({ 
                            content: '❌ **Pengarsipan dibatalkan**', 
                            components: [] 
                        });
                        break;
                }
            }

        } catch (error) {
            console.error('Error Ticket System:', error);
            if (interaction.replied || interaction.deferred) {
                await interaction.followUp({ 
                    content: '❌ **Terjadi kesalahan sistem**', 
                    ephemeral: true 
                });
            } else {
                await interaction.reply({ 
                    content: '❌ **Terjadi kesalahan sistem**', 
                    ephemeral: true 
                });
            }
        }
    });
};