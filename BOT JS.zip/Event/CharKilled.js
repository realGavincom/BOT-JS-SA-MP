const { 
    ActionRowBuilder, ButtonBuilder, ButtonStyle, ModalBuilder, 
    TextInputBuilder, TextInputStyle, EmbedBuilder 
} = require('discord.js');
const config = require('../config.json'); 

module.exports = (client) => {
    client.on('interactionCreate', async interaction => {
        if (interaction.isCommand()) {
            if (interaction.commandName === 'charkilledpanel') {
                const channel = interaction.options.getChannel('channel');

                const row = new ActionRowBuilder().addComponents(
                    new ButtonBuilder()
                        .setCustomId('start_char_killed')
                        .setLabel('🪦 Buat Character Story')
                        .setStyle(ButtonStyle.Primary)
                );

                const embed = new EmbedBuilder()
                    .setTitle('🪦 Character Killed Request')
                    .setDescription('Klik tombol di bawah untuk membuat request character story')
                    .setColor('#0099FF');

                await channel.send({ embeds: [embed], components: [row] });
                await interaction.reply({ content: `Panel berhasil dibuat di ${channel}`, ephemeral: true });
            }
        } 
        else if (interaction.isButton()) {
            if (interaction.customId === 'start_char_killed') {
                const modal = new ModalBuilder()
                    .setCustomId('char_killed_form')
                    .setTitle('Character Killed Request');

                const inputs = [
                    new TextInputBuilder()
                        .setCustomId('nama_korban')
                        .setLabel("Nama IC Korban")
                        .setStyle(TextInputStyle.Short),
                    new TextInputBuilder()
                        .setCustomId('nama_pelaku')
                        .setLabel("Nama IC Pelaku")
                        .setStyle(TextInputStyle.Short),
                    new TextInputBuilder()
                        .setCustomId('waktu')
                        .setLabel("Waktu Kejadian")
                        .setStyle(TextInputStyle.Short),
                    new TextInputBuilder()
                        .setCustomId('kronologi')
                        .setLabel("Cerita Kronologi (Min. 200 karakter)")
                        .setStyle(TextInputStyle.Paragraph)
                ];

                const actionRows = inputs.map(input => new ActionRowBuilder().addComponents(input));

                modal.addComponents(...actionRows);
                await interaction.showModal(modal);
            }
        } 
        else if (interaction.isModalSubmit()) {
            if (interaction.customId === 'char_killed_form') {
                const embed = new EmbedBuilder()
                    .setTitle('🪦 Character Killed Request')
                    .setColor('#0099FF')
                    .addFields(
                        { name: 'Nama Korban', value: interaction.fields.getTextInputValue('nama_korban') },
                        { name: 'Nama Pelaku', value: interaction.fields.getTextInputValue('nama_pelaku') },
                        { name: 'Waktu Kejadian', value: interaction.fields.getTextInputValue('waktu') },
                        { name: 'Kronologi Kejadian', value: interaction.fields.getTextInputValue('kronologi') }
                    )
                    .setFooter({ text: `Request oleh: ${interaction.user.tag}`, iconURL: interaction.user.displayAvatarURL() })
                    .setTimestamp();

                const adminChannel = interaction.guild.channels.cache.get(config.charKilledId);
                if (!adminChannel) {
                    return interaction.reply({ content: '⚠️ Log channel tidak ditemukan!', ephemeral: true });
                }

                await adminChannel.send({ 
                    content: '**Character Killed Request**', 
                    embeds: [embed] 
                });

                await interaction.reply({ 
                    content: '✅ Request berhasil dikirim! Tim kami akan segera meninjau permintaan Anda.', 
                    ephemeral: true 
                });
            }
        }
    });
};