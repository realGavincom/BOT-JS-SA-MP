const { 
    ActionRowBuilder, ButtonBuilder, ButtonStyle, ModalBuilder, 
    TextInputBuilder, TextInputStyle, EmbedBuilder 
} = require('discord.js');
const config = require('../config.json');

module.exports = (client) => {
    client.on('interactionCreate', async interaction => {
        if (interaction.isCommand()) {
            if (interaction.commandName === 'charstorypanel') {
                const channel = interaction.options.getChannel('channel');
                
                const row = new ActionRowBuilder().addComponents(
                    new ButtonBuilder()
                        .setCustomId('start_char_story')
                        .setLabel('📖 Buat Character Story')
                        .setStyle(ButtonStyle.Primary)
                );

                const embed = new EmbedBuilder()
                    .setTitle('📖 Character Story Request')
                    .setDescription('Klik tombol di bawah untuk membuat request character story')
                    .setColor('#0099FF');

                await channel.send({ embeds: [embed], components: [row] });
                await interaction.reply({ content: `Panel berhasil dibuat di ${channel}`, ephemeral: true });
            }
        } 
        else if (interaction.isButton()) {
            if (interaction.customId === 'start_char_story') {
                const modal = new ModalBuilder()
                    .setCustomId('char_story_form')
                    .setTitle('Character Story Request');

                const inputs = [
                    new TextInputBuilder()
                        .setCustomId('nama_ic')
                        .setLabel("Nama IC")
                        .setStyle(TextInputStyle.Short),
                    new TextInputBuilder()
                        .setCustomId('umur_ic')
                        .setLabel("Umur IC")
                        .setStyle(TextInputStyle.Short),
                    new TextInputBuilder()
                        .setCustomId('ttl_ic')
                        .setLabel("Tempat/Tanggal Lahir IC")
                        .setStyle(TextInputStyle.Short),
                    new TextInputBuilder()
                        .setCustomId('story')
                        .setLabel("Cerita Karakter (Min. 200 karakter)")
                        .setStyle(TextInputStyle.Paragraph)
                ];

                const actionRows = inputs.map(input => new ActionRowBuilder().addComponents(input));

                modal.addComponents(...actionRows);
                await interaction.showModal(modal);
            }
        } 
        else if (interaction.isModalSubmit()) {
            if (interaction.customId === 'char_story_form') {
                const embed = new EmbedBuilder()
                    .setTitle('📖 New Character Story Request')
                    .setColor('#0099FF')
                    .addFields(
                        { name: 'Nama IC', value: interaction.fields.getTextInputValue('nama_ic') },
                        { name: 'Umur IC', value: interaction.fields.getTextInputValue('umur_ic') },
                        { name: 'TTL IC', value: interaction.fields.getTextInputValue('ttl_ic') },
                        { name: 'Story', value: interaction.fields.getTextInputValue('story') }
                    )
                    .setFooter({ text: `Request oleh: ${interaction.user.tag}`, iconURL: interaction.user.displayAvatarURL() })
                    .setTimestamp();

                const adminChannel = interaction.guild.channels.cache.get(config.charStoryId);
                if (!adminChannel) {
                    return interaction.reply({ content: '⚠️ Log channel tidak ditemukan!', ephemeral: true });
                }

                await adminChannel.send({ 
                    content: '**New Character Story Request**', 
                    embeds: [embed] 
                });

                await interaction.reply({ 
                    content: '✅ Request berhasil dikirim! Tim kami akan segera meninjau permintaan Anda.', 
                    ephemeral: true 
                });
            }
        }
    });
};