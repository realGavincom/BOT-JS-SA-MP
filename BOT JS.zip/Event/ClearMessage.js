module.exports = (client) => {
    client.on('interactionCreate', async (interaction) => {
        if (!interaction.isCommand()) return;

        if (interaction.commandName === 'clear') {
            const amount = interaction.options.getInteger('jumlah');
            
            if (amount < 1 || amount > 1000) {
                return interaction.reply({
                    content: '❌ Jumlah pesan harus antara 1-1000',
                    ephemeral: true
                });
            }

            try {
                await interaction.channel.bulkDelete(amount);
                await interaction.reply({ 
                    content: `🧹 Berhasil hapus ${amount} pesan!`,
                    ephemeral: true 
                });
            } catch (error) {
                console.error('Error:', error);
                await interaction.reply({
                    content: '❌ Gagal menghapus pesan!',
                    ephemeral: true
                });
            }
        }
    });
};