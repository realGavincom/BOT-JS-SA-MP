const { ChannelType } = require('discord.js');

module.exports = (client) => {
    client.on('messageCreate', async message => {
        try {
            if (message.channel.id === '1325181429650427934' && message.attachments.size > 0) {
                const thread = await message.startThread({
                    name: message.content || 'Foto Discussion',
                    autoArchiveDuration: 1440,
                    reason: 'Auto thread untuk foto',
                });
                
                await thread.send(`📸 Thread otomatis untuk foto yang diupload oleh ${message.author}`);
            }
        } catch (error) {
            console.error('Error creating thread:', error);
        }
    });
};