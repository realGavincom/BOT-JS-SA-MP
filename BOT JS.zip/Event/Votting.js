const { ActionRowBuilder, ButtonBuilder, ButtonStyle, EmbedBuilder } = require('discord.js');
const config = require('../config.json');

const voteRecords = new Map();

module.exports = {
    name: 'votepanel',
    description: 'Buat panel voting',
    permissions: [config.adminRoleId],
    options: [
        {
            name: 'judul',
            type: 3,
            description: 'Judul voting',
            required: true
        },
        {
            name: 'deskripsi',
            type: 3,
            description: 'Deskripsi voting',
            required: true
        },
        {
            name: 'pilihan_pertama',
            type: 3,
            description: 'Teks untuk pilihan pertama',
            required: true
        },
        {
            name: 'pilihan_kedua',
            type: 3,
            description: 'Teks untuk pilihan kedua',
            required: true
        },
        {
            name: 'emoji_pertama',
            type: 3,
            description: 'Emoji untuk pilihan pertama (contoh: 👍)',
            required: false
        },
        {
            name: 'emoji_kedua',
            type: 3,
            description: 'Emoji untuk pilihan kedua (contoh: 👎)',
            required: false
        }
    ],
    async execute(interaction) {
        if (!interaction.member.roles.cache.has(config.adminRoleId)) {
            return interaction.reply({ 
                content: '❌ Anda tidak memiliki izin untuk menggunakan command ini!', 
                ephemeral: true 
            });
        }

        const judul = interaction.options.getString('judul');
        const deskripsi = interaction.options.getString('deskripsi');
        const setuju = interaction.options.getString('pilihan_pertama');
        const tidakSetuju = interaction.options.getString('pilihan_kedua');
        const emojiSetuju = interaction.options.getString('emoji_pertama') || '👍';
        const emojiTidakSetuju = interaction.options.getString('emoji_kedua') || '👎';

        const embed = new EmbedBuilder()
            .setTitle(judul)
            .setDescription(deskripsi)
            .setColor('#00FF00')
            .addFields({ 
                name: '**📊 Hasil Voting**', 
                value: 'PILIHAN PERTAMA: 0\nPILIHAN KEDUA: 0' 
            })
            .setFooter({ text: 'Voting System', iconURL: interaction.guild.iconURL() })
            .setTimestamp();

        const buttons = new ActionRowBuilder().addComponents(
            new ButtonBuilder()
                .setCustomId('vote_setuju')
                .setLabel(setuju)
                .setStyle(ButtonStyle.Success)
                .setEmoji(emojiSetuju),
            new ButtonBuilder()
                .setCustomId('vote_tidak_setuju')
                .setLabel(tidakSetuju)
                .setStyle(ButtonStyle.Danger)
                .setEmoji(emojiTidakSetuju)
        );

        const response = await interaction.reply({ 
            embeds: [embed], 
            components: [buttons],
            fetchReply: true 
        });

        voteRecords.set(response.id, {
            setuju: new Set(),
            tidakSetuju: new Set(),
            message: response
        });
    }
};

module.exports.voteRecords = voteRecords;