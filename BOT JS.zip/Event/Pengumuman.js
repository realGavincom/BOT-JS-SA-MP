module.exports = (client) => {
    client.on('interactionCreate', async (interaction) => {
        if (!interaction.isCommand()) return;

        if (interaction.commandName === 'pengumuman') {
            await interaction.deferReply({ ephemeral: true });

            const channel = interaction.options.getChannel('channel');
            const title = interaction.options.getString('judul');
            const description = interaction.options.getString('deskripsi');

            if (!channel.isTextBased()) {
                return interaction.editReply({
                    content: '⛔ Harap pilih channel text!'
                });
            }

            try {
                const embed = {
                    color: 0xFFFFFF,
                    title: title,
                    description: description,
                    timestamp: new Date(),
                    footer: {
                        text: `Diposting oleh ${interaction.user.tag}`,
                        icon_url: interaction.user.displayAvatarURL()
                    }
                };

                await channel.send({ embeds: [embed] });
                await interaction.editReply({
                    content: `✅ Pengumuman berhasil dikirim ke ${channel}`
                });
            } catch (error) {
                console.error('Error pengumuman:', error);
                await interaction.editReply({
                    content: '❌ Gagal mengirim pengumuman!'
                });
            }
        }
    });
};