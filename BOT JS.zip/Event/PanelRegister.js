const { ActionRowBuilder, ButtonBuilder, ButtonStyle, EmbedBuilder } = require('discord.js');

module.exports = (client, memberRoleId, allowedRoleId) => {
    client.on('interactionCreate', async (interaction) => {
        if (interaction.isButton() && interaction.customId === 'register_button') {
            try {
                const role = interaction.guild.roles.cache.get(memberRoleId);
                if (!role) throw new Error('Role tidak ditemukan');
                
                await interaction.member.roles.add(role);
                await interaction.reply({
                    content: '🎉 Selamat! Role Warga berhasil diberikan!',
                    ephemeral: true
                });
            } catch (error) {
                console.error('Error:', error);
                await interaction.reply({
                    content: '❌ Gagal memberikan role. Hubungi Admin!',
                    ephemeral: true
                });
            }
            return;
        }

        if (interaction.isCommand() && interaction.commandName === 'panelregister') {
            if (!interaction.member.roles.cache.has(allowedRoleId)) {
                return interaction.reply({
                    content: '⛔ Akses ditolak!',
                    ephemeral: true
                });
            }

            const embed = new EmbedBuilder()
                .setColor(0xE74C3C)
                .setAuthor({
                    name: 'Registrasi Warga',
                    iconURL: 'https://cdn.discordapp.com/attachments/1335575590778048624/1335586728702115873/20250105_150727.png?ex=67a0b592&is=679f6412&hm=0f8ea8111226468c4b14c2963e3ab7191fa165aee0b69ca778f9b234a7145b3d&'
                })
                .setThumbnail('https://cdn.discordapp.com/attachments/1335575590778048624/1335586728702115873/20250105_150727.png?ex=67a0b592&is=679f6412&hm=0f8ea8111226468c4b14c2963e3ab7191fa165aee0b69ca778f9b234a7145b3d&')
                .setDescription([
                    '**Selamat datang di Harizontal Roleplay!**',
                    'Selamat datang di dunia penuh cerita dan pengalaman baru! Kami sangat senang Anda bergabung di **Harizontal Roleplay**. Temukan karakter unik, bangun kisahmu sendiri, dan nikmati pengalaman roleplay yang mendalam bersama komunitas yang ramah dan suportif.\n\n\n**Visi:**\nMenjadi komunitas roleplay yang autentik, edukatif, dan menyenangkan.\n\n\n**Misi:**\n- Menciptakan lingkungan bermain yang aman dan inklusif.\n- Mendorong kreativitas dalam pengembangan karakter dan cerita.\n- Menyediakan panduan serta dukungan bagi seluruh pemain.\n- Menjaga kualitas roleplay dengan aturan yang adil.\n\n\n**Tujuan**\n- Mengembangkan komunitas yang aktif dan harmonis.\n- Menyediakan skenario roleplay yang menarik dan beragam.\n- Memberikan ruang eksplorasi bagi karakter pemain.\n\n**💫 Harapan:** Kami berharap Harizontal Roleplay menjadi rumah kedua bagi para pemain, tempat berbagi cerita, pengalaman, dan petualangan seru!\n\n**Silahkan ambil role warga dengan cara menekan tombol button dibawah ini!**'
                ].join('\n\n'))
                .setFooter({
                    text: '©realgavin.com',
                });

            const row = new ActionRowBuilder().addComponents(
                new ButtonBuilder()
                    .setCustomId('register_button')
                    .setLabel('REGISTER NOW')
                    .setStyle(ButtonStyle.Success)
                    .setEmoji('📝')
            );

            const channel = interaction.options.getChannel('channel');
            await channel.send({ embeds: [embed], components: [row] });
            
            await interaction.reply({
                content: `✅ Panel dibuat di ${channel}!`,
                ephemeral: true
            });
        }
    });
};